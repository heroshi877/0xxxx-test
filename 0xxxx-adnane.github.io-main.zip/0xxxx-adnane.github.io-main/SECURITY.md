# Security Policy

## Reporting a Vulnerability

Please refer to https://docs.ens.domains/bug-bounty-program if you would like to report a vulnerability.
