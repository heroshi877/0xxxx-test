import CopyToClipboard from './CopyToClipboard'
export default CopyToClipboard
