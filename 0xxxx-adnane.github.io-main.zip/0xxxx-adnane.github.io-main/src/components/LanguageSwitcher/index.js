import LanguageSwitcher from './LanguageSwitcher'

export default LanguageSwitcher
