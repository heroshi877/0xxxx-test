import DNSNameRegister from './DNSNameRegister'

export default DNSNameRegister
