import NameRegister from './NameRegister'

export default NameRegister
