import KeyValueRecord from './KeyValueRecord'

export default KeyValueRecord
export * from './KeyValueRecord.js'
