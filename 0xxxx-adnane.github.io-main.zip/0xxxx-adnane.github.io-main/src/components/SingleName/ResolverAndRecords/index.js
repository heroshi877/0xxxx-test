import ResolverAndRecords from './ResolverAndRecords'

export default ResolverAndRecords
