export const CONFIRM = 'confirm'
