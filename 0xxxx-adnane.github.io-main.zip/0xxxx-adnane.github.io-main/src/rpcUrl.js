export const rpcUrl = 'https://web3.ens.domains/v1/mainnet'
